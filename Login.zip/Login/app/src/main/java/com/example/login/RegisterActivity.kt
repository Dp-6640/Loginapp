package com.example.login

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class RegisterActivity : AppCompatActivity() {

    private lateinit var etName: EditText
    private lateinit var etMonth: EditText
    private lateinit var etDay: EditText
    private lateinit var etYear: EditText
    private lateinit var etEmail: EditText
    private lateinit var btnSubmit: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_register)

        // Initialize the views
        etName = findViewById(R.id.editTextName)
        etMonth = findViewById(R.id.editTextMonth) // Adjust this according to your XML
        etDay = findViewById(R.id.editTextDay) // Adjust this according to your XML
        etYear = findViewById(R.id.editTextYear) // Adjust this according to your XML
        etEmail = findViewById(R.id.editTextEmail)
        btnSubmit = findViewById(R.id.btnSubmit)

        // Set up the button click listener
        btnSubmit.setOnClickListener {
            val name = etName.text.toString()
            val month = etMonth.text.toString()
            val day = etDay.text.toString()
            val year = etYear.text.toString()
            val email = etEmail.text.toString()

            // Validate the input (basic example)
            if (name.isEmpty() || month.isEmpty() || day.isEmpty() || year.isEmpty() || email.isEmpty()) {
                Toast.makeText(this, "Please fill in all fields", Toast.LENGTH_SHORT).show()
            } else {
                // Construct the birth date string
                val birthDate = "$month/$day/$year"

                // Show the entered details in a Toast (you can replace this with data passing to Activity 2)
                val message = "Name: $name\nBirth Date: $birthDate\nEmail: $email"
                Toast.makeText(this, message, Toast.LENGTH_LONG).show()

                // Optionally, you can proceed to pass data to Activity 2 here
                // Example: startActivity(Intent(this, DisplayActivity::class.java).apply {
                //    putExtra("NAME", name)
                //    putExtra("DOB", birthDate)
                //    putExtra("EMAIL", email)
                // })
            }
        }
    }
}
