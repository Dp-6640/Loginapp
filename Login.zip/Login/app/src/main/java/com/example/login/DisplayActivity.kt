import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.TextView
import com.example.login.R


class DisplayActivity : AppCompatActivity() {

    private lateinit var dbHelper: DBHelper

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_display)

        dbHelper = DBHelper(this)
        val db = dbHelper.writableDatabase

        val textViewDisplay = findViewById<TextView>(R.id.textViewDisplay)
        textViewDisplay.text = "Welcome user! Please enter your details"

        // Receive data from intent
        val name = intent.getStringExtra("NAME")
        val dob = intent.getStringExtra("DOB")
        val email = intent.getStringExtra("EMAIL")

        // Display received data
        val displayText = "Name: $name\nDate of Birth: $dob\nEmail: $email"
        textViewDisplay.text = displayText

        // Store data in SQLite database
        val values = ContentValues().apply {
            put(DBContract.UserEntry.COLUMN_NAME, name)
            put(DBContract.UserEntry.COLUMN_DOB, dob)
            put(DBContract.UserEntry.COLUMN_EMAIL, email)
        }
        val newRowId = db.insert(DBContract.UserEntry.TABLE_NAME, null, values)

        db.close()
    }
}

class DBHelper(context: Context) : SQLiteOpenHelper(context, DATABASE_NAME, null, DATABASE_VERSION) {

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL(DBContract.SQL_CREATE_ENTRIES)
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        db.execSQL(DBContract.SQL_DELETE_ENTRIES)
        onCreate(db)
    }

    companion object {
        // If you change the database schema, you must increment the database version.
        const val DATABASE_VERSION = 1
        const val DATABASE_NAME = "User.db"
    }
}
